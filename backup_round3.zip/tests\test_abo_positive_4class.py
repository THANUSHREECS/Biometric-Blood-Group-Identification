#!/usr/bin/env python3
"""
tests/test_abo_positive_4class.py
=================================
Automated verification tests for the 4-class ABO-positive experiment:
  1. Only A+, AB+, B+, O+ are present in the filtered experiment dataset.
  2. Exact class mapping is {"A+": 0, "AB+": 1, "B+": 2, "O+": 3}.
  3. No train/test/validation leakage (zero intersection between image path sets).
  4. Model output dimension is exactly 4.
  5. Softmax probabilities sum to 1.0 ± 1e-4.
  6. Prediction labels map correctly between IDs and class names.
  7. Existing production files remain bit-for-bit unchanged (verified via SHA-256).
  8. Baseline calculation uses TRAIN distribution correctly.
  9. Test data is not used during training.
  10. Test metrics are not used for model selection.
"""

import os
import sys
import json
import hashlib
import unittest
import numpy as np
import pandas as pd

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, PROJECT_ROOT)

DATASET_MANIFEST_PATH = os.path.join(PROJECT_ROOT, "outputs", "dataset_manifest.csv")
MODELS_DIR = os.path.join(PROJECT_ROOT, "models", "abo_positive_4class")
OUTPUTS_DIR = os.path.join(PROJECT_ROOT, "outputs", "abo_positive_4class")

# Locked Production SHA-256 Hashes
PROTECTED_FILES = {
    "models/resnet50_improved_blood_group.keras": "a377510597cc216e95f3f4aad7f59c61e2d29ad4723363ffdda767dbc927a1f2",
    "models/vgg16_blood_group.keras": "7f46e1c52000773e98656c87278107c10350095384df1c3bdf12319d6632cc6c",
    "models/efficientnetb0_blood_group.keras": "63e6f06f4c15c86f3e536e8bc6153475f14117075223deab8d561f9cb84f68ab",
    "models/class_names.json": "f8a6889b331406313c274abb8ecf548e4aeab92b255c0ce78d3c22b4b09fee6d",
    "outputs/ensemble_weights.json": "12f23f6ce7562c4852a6e9f96560d58fda4636bc8f40d02149398db46743d604",
    "src/config.py": "e0616ca178744f8d20e7cae6a6cb1177f46e2f373a2e044ba56c74ac930d817f",
    "src/preprocessing.py": "569cdec24d516c8b8b66856623566287fb9c6b3f1deb35a345d6bc8d851146f7",
    "src/predictor.py": "ceb4c34ed082a8182ef32ee39f38660943320a16cc4aa9d30acf2a9cce0d4e5e"
}

EXPECTED_CLASS_MAPPING = {
    "A+": 0,
    "AB+": 1,
    "B+": 2,
    "O+": 3
}


def compute_sha256(filepath):
    sha = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            sha.update(chunk)
    return sha.hexdigest()


class TestABOPositive4ClassExperiment(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.df = pd.read_csv(DATASET_MANIFEST_PATH)
        cls.filtered_df = cls.df[cls.df["class_name"].isin(["A+", "AB+", "B+", "O+"])].copy()

    def test_1_dataset_filtering_only_abo_positive(self):
        """Test 1: Only A+, AB+, B+, O+ classes are present, and negatives are excluded."""
        unique_classes = set(self.filtered_df["class_name"].unique())
        self.assertEqual(unique_classes, {"A+", "AB+", "B+", "O+"})
        
        # Verify negative classes are excluded
        for neg_class in ["A-", "AB-", "B-", "O-"]:
            self.assertNotIn(neg_class, unique_classes)

        # Verify expected counts per partition
        train_counts = self.filtered_df[self.filtered_df["split"] == "train"]["class_name"].value_counts().to_dict()
        val_counts = self.filtered_df[self.filtered_df["split"] == "val"]["class_name"].value_counts().to_dict()
        test_counts = self.filtered_df[self.filtered_df["split"] == "test"]["class_name"].value_counts().to_dict()

        self.assertEqual(train_counts, {"A+": 395, "AB+": 493, "B+": 454, "O+": 596})
        self.assertEqual(val_counts, {"A+": 85, "AB+": 106, "B+": 97, "O+": 128})
        self.assertEqual(test_counts, {"A+": 85, "AB+": 106, "B+": 97, "O+": 127})

    def test_2_exact_class_mapping(self):
        """Test 2: Class mapping is exactly {"A+": 0, "AB+": 1, "B+": 2, "O+": 3}."""
        mapping_file = os.path.join(MODELS_DIR, "class_mapping.json")
        if os.path.exists(mapping_file):
            with open(mapping_file, "r") as f:
                data = json.load(f)
            self.assertEqual(data["class_to_id"], EXPECTED_CLASS_MAPPING)
            self.assertEqual(data["id_to_class"], {str(v): k for k, v in EXPECTED_CLASS_MAPPING.items()})

    def test_3_no_train_val_test_leakage(self):
        """Test 3: Zero partition leakage across train, val, and test splits."""
        train_paths = set(self.filtered_df[self.filtered_df["split"] == "train"]["image_path"])
        val_paths = set(self.filtered_df[self.filtered_df["split"] == "val"]["image_path"])
        test_paths = set(self.filtered_df[self.filtered_df["split"] == "test"]["image_path"])

        self.assertEqual(len(train_paths.intersection(val_paths)), 0, "Train and Val overlap!")
        self.assertEqual(len(train_paths.intersection(test_paths)), 0, "Train and Test overlap!")
        self.assertEqual(len(val_paths.intersection(test_paths)), 0, "Val and Test overlap!")

    def test_4_model_output_dimension(self):
        """Test 4: Model output dimension is exactly 4."""
        model_path = os.path.join(MODELS_DIR, "best_model.keras")
        if os.path.exists(model_path):
            import tensorflow as tf
            model = tf.keras.models.load_model(model_path, compile=False)
            output_shape = model.output_shape
            self.assertEqual(output_shape[-1], 4)

    def test_5_softmax_probabilities_sum_to_one(self):
        """Test 5: Softmax probabilities sum to 1.0 ± 1e-4."""
        preds_file = os.path.join(OUTPUTS_DIR, "test_predictions.csv")
        if os.path.exists(preds_file):
            df_preds = pd.read_csv(preds_file)
            prob_cols = ["prob_A+", "prob_AB+", "prob_B+", "prob_O+"]
            prob_sums = df_preds[prob_cols].sum(axis=1)
            np.testing.assert_allclose(prob_sums, 1.0, atol=1e-3)

    def test_6_prediction_labels_map_correctly(self):
        """Test 6: Prediction labels map correctly between IDs and class names."""
        preds_file = os.path.join(OUTPUTS_DIR, "test_predictions.csv")
        if os.path.exists(preds_file):
            df_preds = pd.read_csv(preds_file)
            for _, row in df_preds.iterrows():
                expected_cname = {0: "A+", 1: "AB+", 2: "B+", 3: "O+"}[row["predicted_id"]]
                self.assertEqual(row["predicted_class"], expected_cname)

    def test_7_production_files_unchanged(self):
        """Test 7: Existing production 8-class files remain bit-for-bit unchanged (SHA-256)."""
        for rel_path, expected_hash in PROTECTED_FILES.items():
            full_path = os.path.join(PROJECT_ROOT, rel_path)
            self.assertTrue(os.path.exists(full_path), f"Protected file missing: {rel_path}")
            current_hash = compute_sha256(full_path)
            self.assertEqual(
                current_hash, expected_hash,
                f"PROTECTED PRODUCTION FILE MODIFIED: {rel_path} (Current: {current_hash}, Expected: {expected_hash})"
            )

    def test_8_baseline_uses_train_distribution(self):
        """Test 8: Baseline calculation accurately uses actual TRAIN distribution."""
        baseline_file = os.path.join(OUTPUTS_DIR, "baseline_metrics.json")
        if os.path.exists(baseline_file):
            with open(baseline_file, "r") as f:
                data = json.load(f)
            train_dist = data["scientific_context"]["train_distribution"]
            self.assertEqual(train_dist, {"A+": 395, "AB+": 493, "B+": 454, "O+": 596})
            self.assertEqual(data["scientific_context"]["majority_class"], "O+")

    def test_9_test_data_not_used_in_training(self):
        """Test 9: Verify training script never ingest test split for fitting."""
        train_config_file = os.path.join(MODELS_DIR, "training_config.json")
        if os.path.exists(train_config_file):
            with open(train_config_file, "r") as f:
                cfg = json.load(f)
            self.assertTrue(cfg.get("two_stage_training", False))
            self.assertIn("train split", cfg.get("class_weights", ""))

    def test_10_test_metrics_not_used_for_model_selection(self):
        """Test 10: Model selection was finalized on validation before test evaluation."""
        test_metrics_file = os.path.join(OUTPUTS_DIR, "test_metrics.json")
        if os.path.exists(test_metrics_file):
            with open(test_metrics_file, "r") as f:
                metrics = json.load(f)
            self.assertIn("audit_record", metrics)
            self.assertIn("test_set_protection_statement", metrics)
            self.assertIn("model_checkpoint_sha256", metrics["audit_record"])


if __name__ == "__main__":
    unittest.main()
"""
tests/test_advisory_layer.py
============================
Unit, API, and integration regression tests for the Advisory UI/API Warning Layer (tau = 0.70).
Verifies all 15 requirements specified in the advisory layer review instructions.
"""

import os
import sys
import json
import numpy as np
import pytest

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, PROJECT_ROOT)

from src.config import ADVISORY_CONFIRMATION_THRESHOLD, CLASS_NAMES
from src.predictor import BloodGroupPredictor
from src.report_generator import generate_pdf_report, REPORTS_DIR
from app import app

@pytest.fixture(scope="module")
def predictor_instance():
    # Instantiate predictor with ensemble enabled (or fallback)
    pred = BloodGroupPredictor()
    return pred

@pytest.fixture(scope="module")
def test_client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client

# 1. confidence = 0.69 -> needs_confirmation = True
def test_1_confidence_below_threshold(predictor_instance):
    adv = predictor_instance._evaluate_advisory(0.69, {"rh_uncertainty": False})
    assert adv["needs_confirmation"] is True
    assert adv["advisory_level"] == "CONFIRMATION_RECOMMENDED"

# 2. confidence = 0.70 -> threshold condition is NOT triggered
def test_2_confidence_exact_threshold(predictor_instance):
    adv = predictor_instance._evaluate_advisory(0.70, {"rh_uncertainty": False})
    assert adv["needs_confirmation"] is False
    assert adv["advisory_level"] == "CONFIDENCE_OK"

# 3. confidence = 0.71 -> needs_confirmation = False (assuming Rh uncertainty is False)
def test_3_confidence_above_threshold(predictor_instance):
    adv = predictor_instance._evaluate_advisory(0.71, {"rh_uncertainty": False})
    assert adv["needs_confirmation"] is False
    assert adv["advisory_level"] == "CONFIDENCE_OK"

# 4. Rh uncertainty = True -> needs_confirmation = True (even if confidence >= 0.70)
def test_4_rh_uncertainty_triggers_confirmation(predictor_instance):
    adv = predictor_instance._evaluate_advisory(0.85, {"rh_uncertainty": True})
    assert adv["needs_confirmation"] is True
    assert adv["advisory_level"] == "CONFIRMATION_RECOMMENDED"

# 5. Both conditions true -> advisory_reason = "LOW_CONFIDENCE_AND_RH_UNCERTAINTY"
def test_5_both_conditions_true(predictor_instance):
    adv = predictor_instance._evaluate_advisory(0.65, {"rh_uncertainty": True})
    assert adv["needs_confirmation"] is True
    assert adv["advisory_reason"] == "LOW_CONFIDENCE_AND_RH_UNCERTAINTY"
    assert adv["advisory_level"] == "CONFIRMATION_RECOMMENDED"

# 6. Low confidence only -> advisory_reason = "LOW_CONFIDENCE"
def test_6_low_confidence_only(predictor_instance):
    adv = predictor_instance._evaluate_advisory(0.65, {"rh_uncertainty": False})
    assert adv["needs_confirmation"] is True
    assert adv["advisory_reason"] == "LOW_CONFIDENCE"
    assert adv["advisory_level"] == "CONFIRMATION_RECOMMENDED"

# 7. Rh uncertainty only -> advisory_reason = "RH_UNCERTAINTY"
def test_7_rh_uncertainty_only(predictor_instance):
    adv = predictor_instance._evaluate_advisory(0.75, {"rh_uncertainty": True})
    assert adv["needs_confirmation"] is True
    assert adv["advisory_reason"] == "RH_UNCERTAINTY"
    assert adv["advisory_level"] == "CONFIRMATION_RECOMMENDED"

# 8. Neither condition -> advisory_reason = "NONE"
def test_8_neither_condition(predictor_instance):
    adv = predictor_instance._evaluate_advisory(0.80, {"rh_uncertainty": False})
    assert adv["needs_confirmation"] is False
    assert adv["advisory_reason"] == "NONE"
    assert adv["advisory_level"] == "CONFIDENCE_OK"

# 9 & 10 & 11. Existing prediction label, probabilities, and confidence values are preserved
def test_9_10_11_prediction_probabilities_confidence_preserved(predictor_instance):
    # Dummy synthetic fingerprint (224, 224, 3)
    dummy_img = np.ones((224, 224, 3), dtype=np.uint8) * 200
    res = predictor_instance.predict(dummy_img, source="upload")
    
    assert res["blood_group"] in CLASS_NAMES
    assert isinstance(res["confidence"], float)
    assert 0.0 <= res["confidence"] <= 1.0
    assert len(res["probabilities"]) == 8
    # Probabilities sum approximately to 1
    prob_sum = sum(res["probabilities"].values())
    assert abs(prob_sum - 1.0) < 0.01

# 12. Advisory threshold remains exactly 0.70
def test_12_advisory_threshold_value(predictor_instance):
    assert ADVISORY_CONFIRMATION_THRESHOLD == 0.70
    assert predictor_instance.advisory_threshold == 0.70

# 13. API status and response structure contain all required advisory keys
def test_13_api_response_structure(test_client):
    status_res = test_client.get("/api/status")
    assert status_res.status_code == 200
    data = status_res.get_json()
    assert "advisory_layer" in data
    assert data["advisory_layer"]["threshold"] == 0.70
    assert data["advisory_layer"]["enabled"] is True

# 14. PDF generation succeeds with advisory information
def test_14_pdf_generation_with_advisory():
    from PIL import Image
    test_img_path = os.path.join(REPORTS_DIR, "test_dummy_thumb.png")
    Image.new("RGB", (100, 100), color="gray").save(test_img_path)

    pdf_path = generate_pdf_report(
        prediction_id=99999,
        timestamp="2026-09-08 12:00:00",
        input_type="Test Sample",
        image_path=test_img_path,
        predicted_group="A+",
        confidence=0.82,
        probabilities={"A+": 0.82, "A-": 0.02, "B+": 0.05, "B-": 0.01, "AB+": 0.04, "AB-": 0.01, "O+": 0.04, "O-": 0.01},
        status="NORMAL",
        model_name="Champion Ensemble V2",
        advisory_level="CONFIDENCE_OK",
        advisory_reason="NONE",
        advisory_message="Advisory threshold passed. This does not constitute medical verification.",
        advisory_threshold=0.70,
        needs_confirmation=False
    )
    assert os.path.exists(pdf_path)
    assert os.path.getsize(pdf_path) > 1000
    # Clean up test artifacts
    if os.path.exists(test_img_path):
        os.remove(test_img_path)
    if os.path.exists(pdf_path):
        os.remove(pdf_path)

# 15. Backward compatibility of existing predictor output is preserved
def test_15_backward_compatibility(predictor_instance):
    dummy_img = np.ones((224, 224, 3), dtype=np.uint8) * 200
    res = predictor_instance.predict(dummy_img, source="upload")
    
    # Required legacy fields
    legacy_keys = ["blood_group", "confidence", "status", "message", "probabilities", "is_low_confidence"]
    for k in legacy_keys:
        assert k in res, f"Missing legacy key: {k}"
        
    # New additive advisory keys
    advisory_keys = ["needs_confirmation", "advisory_threshold", "advisory_level", "advisory_reason", "advisory_message"]
    for k in advisory_keys:
        assert k in res, f"Missing advisory key: {k}"
import os
import unittest
import json
from app import app

class TestFlaskApp(unittest.TestCase):
    def setUp(self):
        app.config["TESTING"] = True
        self.client = app.test_client()

    def test_get_index(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"HemoPrint AI", response.data)
        self.assertIn(b"MANDATORY MEDICAL DISCLAIMER", response.data)

    def test_get_history_page(self):
        response = self.client.get("/history")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Prediction Audit Trail", response.data)

    def test_api_status(self):
        response = self.client.get("/api/status")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(data["status"], "online")
        self.assertIn("model", data)
        self.assertIn("scanner", data)

    def test_api_history(self):
        response = self.client.get("/api/history")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("records", data)
        self.assertIn("total", data)

    def test_scanner_connect_disconnect(self):
        conn_res = self.client.post("/api/scanner/connect")
        self.assertEqual(conn_res.status_code, 200)
        data = conn_res.get_json()
        self.assertTrue(data["connected"])

        disconn_res = self.client.post("/api/scanner/disconnect")
        self.assertEqual(disconn_res.status_code, 200)
        data_d = disconn_res.get_json()
        self.assertTrue(data_d["disconnected"])

if __name__ == "__main__":
    unittest.main()
"""
tests/test_calibration.py
=========================
Regression and verification tests for post-hoc confidence calibration experiment:
1. Temperature must always be > 0.
2. Softmax(logits / T) sums approximately to 1.
3. T=1 produces original probabilities.
4. Calibration does not modify model weights.
5. Calibration does not modify source images.
6. Validation-only fitting.
7. Test labels are never used for temperature optimization.
8. Reconstructed 8-class output contains exactly 8 classes.
9. Deterministic calibration.
10. Production model files remain unchanged.
"""

import os
import sys
import json
import hashlib
import numpy as np
import pandas as pd
import pytest

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, PROJECT_ROOT)

from scripts.calibration_experiments.run_calibration_experiment import (
    softmax,
    compute_nll,
    fit_temperature,
    reconstruct_8class_probs,
    audit_production_locks,
    TWO_STAGE_MODEL_PATH,
    EXPERIMENT_MODELS_DIR,
    PRODUCTION_LOCK_FILES
)
from src.config import CLASS_NAMES, DATASET_MANIFEST_PATH

@pytest.fixture(scope="module")
def temp_params():
    param_path = os.path.join(EXPERIMENT_MODELS_DIR, "temperature_params.json")
    assert os.path.exists(param_path), f"Parameters file missing: {param_path}"
    with open(param_path, "r") as f:
        return json.load(f)

# 1. Temperature must always be > 0
def test_1_temperature_positive(temp_params):
    t_abo = temp_params["t_abo"]
    t_rh = temp_params["t_rh"]
    assert t_abo > 0.0, f"T_ABO must be > 0, got {t_abo}"
    assert t_rh > 0.0, f"T_Rh must be > 0, got {t_rh}"

# 2. Softmax(logits / T) sums approximately to 1
def test_2_softmax_sums_to_one():
    np.random.seed(42)
    logits = np.random.randn(20, 4)
    for T in [0.5, 1.0, 1.5, 2.0]:
        probs = softmax(logits, temperature=T)
        sums = np.sum(probs, axis=-1)
        np.testing.assert_allclose(sums, np.ones(20), rtol=1e-6, atol=1e-6)

# 3. T=1 produces original probabilities
def test_3_temperature_one_is_identity():
    np.random.seed(42)
    logits = np.random.randn(15, 4)
    p_t1 = softmax(logits, temperature=1.0)
    # Manual standard softmax
    e = np.exp(logits - np.max(logits, axis=-1, keepdims=True))
    p_expected = e / np.sum(e, axis=-1, keepdims=True)
    np.testing.assert_allclose(p_t1, p_expected, rtol=1e-7, atol=1e-7)

# 4. Calibration does not modify model weights
def test_4_calibration_does_not_modify_model_weights():
    import tensorflow as tf
    model = tf.keras.models.load_model(TWO_STAGE_MODEL_PATH, compile=False)
    # Check that model weights are non-empty and finite
    weights = model.get_weights()
    assert len(weights) > 0
    for w in weights:
        assert np.all(np.isfinite(w))

# 5. Calibration does not modify source images
def test_5_calibration_does_not_modify_source_images():
    manifest_df = pd.read_csv(DATASET_MANIFEST_PATH)
    # Sample 5 images from val and test
    val_sample = manifest_df[manifest_df["split"] == "val"].iloc[0]["image_path"]
    test_sample = manifest_df[manifest_df["split"] == "test"].iloc[0]["image_path"]
    assert os.path.exists(val_sample)
    assert os.path.exists(test_sample)
    assert os.path.getsize(val_sample) > 0
    assert os.path.getsize(test_sample) > 0

# 6. Validation-only fitting
def test_6_validation_only_fitting(temp_params):
    assert temp_params["fitted_on"] == "validation_split_only"
    assert temp_params["validation_samples"] == 898

# 7. Test labels are never used for temperature optimization
def test_7_test_labels_never_used_in_optimization():
    # Verify fit_temperature works exclusively on given tensors
    np.random.seed(123)
    val_logits = np.random.randn(50, 4)
    val_labels = np.random.randint(0, 4, size=50)
    T = fit_temperature(val_logits, val_labels, "TestDummy")
    assert T > 0.0

# 8. Reconstructed 8-class output contains exactly 8 classes and sums to 1.0
def test_8_reconstructed_8class_output():
    np.random.seed(99)
    p_abo = softmax(np.random.randn(10, 4), temperature=1.0)
    p_rh = softmax(np.random.randn(10, 2), temperature=1.0)
    p_8 = reconstruct_8class_probs(p_abo, p_rh)

    assert p_8.shape == (10, 8), f"Expected shape (10, 8), got {p_8.shape}"
    assert len(CLASS_NAMES) == 8
    sums = np.sum(p_8, axis=1)
    np.testing.assert_allclose(sums, np.ones(10), rtol=1e-6, atol=1e-6)

# 9. Deterministic calibration
def test_9_deterministic_calibration():
    np.random.seed(777)
    logits = np.random.randn(100, 4)
    labels = np.random.randint(0, 4, size=100)
    t1 = fit_temperature(logits, labels, "Det1")
    t2 = fit_temperature(logits, labels, "Det2")
    assert abs(t1 - t2) < 1e-9, f"Calibration not deterministic: {t1} vs {t2}"

# 10. Production model files remain unchanged
def test_10_production_models_unchanged():
    hashes = audit_production_locks("TEST-SUITE")
    assert len(hashes) == len(PRODUCTION_LOCK_FILES)
    for p, sha in hashes.items():
        assert sha is not None, f"Locked file missing: {p}"
import os
import unittest
import tempfile
from src.database import init_db, insert_prediction, get_prediction_by_id, get_all_predictions

class TestDatabase(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.test_db = os.path.join(self.temp_dir, "test_blood_group.db")

    def tearDown(self):
        if os.path.exists(self.test_db):
            os.remove(self.test_db)
        if os.path.exists(self.temp_dir):
            os.rmdir(self.temp_dir)

    def test_init_and_insert(self):
        init_db(self.test_db)
        rec_id = insert_prediction(
            input_type="upload",
            image_path="test_image.bmp",
            predicted_group="O+",
            confidence=0.88,
            status="NORMAL",
            notes="Test prediction",
            db_path=self.test_db
        )
        self.assertIsInstance(rec_id, int)
        self.assertGreater(rec_id, 0)

        # Fetch by ID
        rec = get_prediction_by_id(rec_id, db_path=self.test_db)
        self.assertIsNotNone(rec)
        self.assertEqual(rec["predicted_group"], "O+")
        self.assertEqual(rec["confidence"], 0.88)
        self.assertEqual(rec["input_type"], "upload")

        # Fetch all
        all_recs = get_all_predictions(limit=10, db_path=self.test_db)
        self.assertEqual(len(all_recs), 1)

if __name__ == "__main__":
    unittest.main()
import os
import unittest
import pandas as pd
import json

class TestDatasetPreparation(unittest.TestCase):
    def setUp(self):
        self.project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        self.manifest_path = os.path.join(self.project_root, "outputs", "dataset_manifest.csv")
        self.report_path = os.path.join(self.project_root, "outputs", "dataset_report.json")
        self.class_names_path = os.path.join(self.project_root, "models", "class_names.json")
        self.quarantine_manifest_path = os.path.join(self.project_root, "data", "quarantine", "quarantine_manifest.json")
        self.raw_dir = os.path.join(self.project_root, "data", "raw")
        self.processed_dir = os.path.join(self.project_root, "data", "processed")
        self.sample_dir = os.path.join(self.project_root, "data", "sample")

    def test_class_names_json(self):
        self.assertTrue(os.path.exists(self.class_names_path))
        with open(self.class_names_path) as f:
            data = json.load(f)
        self.assertIn("class_names", data)
        self.assertEqual(len(data["class_names"]), 8)
        expected = ["A+", "A-", "AB+", "AB-", "B+", "B-", "O+", "O-"]
        self.assertEqual(data["class_names"], expected)
        for idx, name in enumerate(expected):
            self.assertEqual(data["class_to_id"][name], idx)

    def test_manifest_csv_integrity(self):
        self.assertTrue(os.path.exists(self.manifest_path))
        df = pd.read_csv(self.manifest_path)
        # Check required columns
        for col in ["image_path", "class_name", "class_id", "split"]:
            self.assertIn(col, df.columns)
        
        # Check total clean count
        self.assertEqual(len(df), 5985)
        
        # Check all splits exist
        splits = set(df["split"].unique())
        self.assertEqual(splits, {"train", "val", "test"})
        
        # Check split counts
        train_count = (df["split"] == "train").sum()
        val_count = (df["split"] == "val").sum()
        test_count = (df["split"] == "test").sum()
        self.assertEqual(train_count, 4189)
        self.assertEqual(val_count, 898)
        self.assertEqual(test_count, 898)
        
        # Check that each class is in all 3 splits
        for c in ["A+", "A-", "AB+", "AB-", "B+", "B-", "O+", "O-"]:
            self.assertGreater((df[df["split"] == "train"]["class_name"] == c).sum(), 0)
            self.assertGreater((df[df["split"] == "val"]["class_name"] == c).sum(), 0)
            self.assertGreater((df[df["split"] == "test"]["class_name"] == c).sum(), 0)

    def test_quarantine_manifest(self):
        self.assertTrue(os.path.exists(self.quarantine_manifest_path))
        with open(self.quarantine_manifest_path) as f:
            data = json.load(f)
        self.assertEqual(data["duplicate_groups_count"], 11)
        self.assertEqual(data["total_quarantined"], 15)

    def test_sample_fingerprints(self):
        self.assertTrue(os.path.exists(self.sample_dir))
        samples = os.listdir(self.sample_dir)
        self.assertEqual(len(samples), 8)

if __name__ == "__main__":
    unittest.main()
import os
import unittest
import io
import json
from app import app
from src.config import SAMPLE_IMAGE_DIR

class TestEndToEndWorkflow(unittest.TestCase):
    def setUp(self):
        app.config["TESTING"] = True
        self.client = app.test_client()

    def test_upload_and_download_report_workflow(self):
        sample_path = os.path.join(SAMPLE_IMAGE_DIR, "A+.bmp")
        self.assertTrue(os.path.exists(sample_path))

        with open(sample_path, "rb") as f:
            file_bytes = f.read()

        # 1. Test POST /api/upload
        data = {
            "file": (io.BytesIO(file_bytes), "sample_test_A+.bmp")
        }
        res = self.client.post("/api/upload", data=data, content_type="multipart/form-data")
        self.assertEqual(res.status_code, 200)
        res_json = res.get_json()

        self.assertTrue(res_json["success"])
        self.assertIn("prediction_id", res_json)
        self.assertIn(res_json["blood_group"], ["A+", "A-", "AB+", "AB-", "B+", "B-", "O+", "O-"])
        self.assertIn("probabilities", res_json)
        self.assertEqual(len(res_json["probabilities"]), 8)

        pred_id = res_json["prediction_id"]

        # 2. Test GET /api/report/<id>
        rep_res = self.client.get(f"/api/report/{pred_id}")
        self.assertEqual(rep_res.status_code, 200)
        self.assertEqual(rep_res.mimetype, "application/pdf")
        self.assertGreater(len(rep_res.data), 5000)

    def test_mfs100_capture_and_history_workflow(self):
        # 1. Test POST /api/capture
        cap_res = self.client.post("/api/capture", json={"sample_class": "O+"})
        self.assertEqual(cap_res.status_code, 200)
        cap_json = cap_res.get_json()

        self.assertTrue(cap_json["success"])
        self.assertIn("prediction_id", cap_json)
        self.assertEqual(cap_json["scanner_mode"], "mock")

        # 2. Test GET /api/history
        hist_res = self.client.get("/api/history")
        self.assertEqual(hist_res.status_code, 200)
        hist_json = hist_res.get_json()
        self.assertGreater(hist_json["total"], 0)

if __name__ == "__main__":
    unittest.main()
"""
tests/test_left_thumb_protocol.py
Automated tests for the LEFT THUMB acquisition protocol standardization.

Verifies:
- finger_used=LEFT_THUMB is stored correctly in the DB for MFS100 captures.
- Upload records do NOT receive finger_used (null).
- PDF report correctly displays Standard Acquisition Finger: LEFT THUMB.
- PDF is backward-compatible when finger_used is not passed.
- Model probabilities are unchanged (finger_used is metadata only).
- No prediction is forced to any blood group based on finger_used.
- 3-scan consensus records store finger_used=LEFT_THUMB.
- Upload mode is completely unaffected.
"""

import os
import sys
import tempfile
import unittest
import sqlite3

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.database import init_db, insert_prediction, get_prediction_by_id, get_all_predictions
from src.report_generator import generate_pdf_report
from src.config import SAMPLE_IMAGE_DIR


def _temp_db():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    return path


def _sample_probs():
    return {
        "A+": 0.75, "A-": 0.05, "AB+": 0.05, "AB-": 0.02,
        "B+": 0.05, "B-": 0.02, "O+": 0.05, "O-": 0.01
    }


def _sample_img():
    p = os.path.join(SAMPLE_IMAGE_DIR, "A+.bmp")
    return p if os.path.exists(p) else None


class TestLeftThumbDB(unittest.TestCase):
    """Database-layer tests for finger_used metadata."""

    def setUp(self):
        self.db = _temp_db()
        init_db(self.db)

    def tearDown(self):
        if os.path.exists(self.db):
            os.remove(self.db)

    def test_finger_used_stored_for_mfs100_capture(self):
        """MFS100 physical capture record stores finger_used=LEFT_THUMB."""
        rec_id = insert_prediction(
            input_type="MFS100",
            image_path="cap_001.bmp",
            predicted_group="O+",
            confidence=0.92,
            status="NORMAL",
            notes="Hardware capture",
            finger_used="LEFT_THUMB",
            db_path=self.db
        )
        record = get_prediction_by_id(rec_id, db_path=self.db)
        self.assertIsNotNone(record)
        self.assertEqual(record["finger_used"], "LEFT_THUMB")

    def test_finger_used_not_set_for_upload(self):
        """Upload records have finger_used=None."""
        rec_id = insert_prediction(
            input_type="upload",
            image_path="upload_abc.bmp",
            predicted_group="A+",
            confidence=0.85,
            status="NORMAL",
            notes="File upload",
            finger_used=None,
            db_path=self.db
        )
        record = get_prediction_by_id(rec_id, db_path=self.db)
        self.assertIsNotNone(record)
        self.assertIsNone(record["finger_used"])

    def test_consensus_finger_used_metadata(self):
        """3-scan consensus records store finger_used=LEFT_THUMB and correct input_type."""
        rec_id = insert_prediction(
            input_type="MFS100 Consensus - Left Thumb (3 Impressions)",
            image_path="cap_consensus_003.bmp",
            predicted_group="O+",
            confidence=0.94,
            status="NORMAL",
            notes="Consensus capture",
            finger_used="LEFT_THUMB",
            db_path=self.db
        )
        record = get_prediction_by_id(rec_id, db_path=self.db)
        self.assertIsNotNone(record)
        self.assertEqual(record["finger_used"], "LEFT_THUMB")
        self.assertIn("Left Thumb", record["input_type"])

    def test_migration_safe_column_addition(self):
        """finger_used column is present after init_db."""
        conn = sqlite3.connect(self.db)
        cols = [row[1] for row in conn.execute("PRAGMA table_info(predictions)").fetchall()]
        conn.close()
        self.assertIn("finger_used", cols)

    def test_upload_unaffected_by_protocol(self):
        """Multiple upload records all have finger_used=None."""
        for i in range(3):
            insert_prediction(
                input_type="upload",
                image_path=f"upload_{i}.bmp",
                predicted_group="B+",
                confidence=0.80,
                finger_used=None,
                db_path=self.db
            )
        records = get_all_predictions(limit=10, db_path=self.db)
        for r in records:
            self.assertIsNone(r["finger_used"],
                msg=f"Upload record should have finger_used=None, got: {r['finger_used']}")


class TestLeftThumbPDF(unittest.TestCase):
    """PDF report tests for the finger_used field."""

    def test_pdf_includes_left_thumb(self):
        """PDF with finger_used=LEFT_THUMB generates without error."""
        pdf_path = generate_pdf_report(
            prediction_id=77001,
            timestamp="2026-09-05 12:00:00",
            input_type="MFS100 Consensus (3 Impressions) | Standard Finger: LEFT THUMB",
            image_path=_sample_img(),
            predicted_group="O+",
            confidence=0.9459,
            probabilities=_sample_probs(),
            status="NORMAL",
            finger_used="LEFT_THUMB"
        )
        self.assertTrue(os.path.exists(pdf_path))
        self.assertGreater(os.path.getsize(pdf_path), 5000)
        if os.path.exists(pdf_path):
            os.remove(pdf_path)

    def test_pdf_without_finger_used_backward_compatible(self):
        """PDF without finger_used param generates normally (backward-compatible)."""
        pdf_path = generate_pdf_report(
            prediction_id=77002,
            timestamp="2026-09-05 12:01:00",
            input_type="MFS100 (Mock)",
            image_path=_sample_img(),
            predicted_group="A+",
            confidence=0.85,
            probabilities=_sample_probs(),
            status="NORMAL"
        )
        self.assertTrue(os.path.exists(pdf_path))
        self.assertGreater(os.path.getsize(pdf_path), 5000)
        if os.path.exists(pdf_path):
            os.remove(pdf_path)

    def test_pdf_upload_no_finger_used(self):
        """Upload PDF with finger_used=None generates normally."""
        pdf_path = generate_pdf_report(
            prediction_id=77003,
            timestamp="2026-09-05 12:02:00",
            input_type="Upload",
            image_path=_sample_img(),
            predicted_group="B+",
            confidence=0.78,
            probabilities=_sample_probs(),
            status="NORMAL",
            finger_used=None
        )
        self.assertTrue(os.path.exists(pdf_path))
        self.assertGreater(os.path.getsize(pdf_path), 5000)
        if os.path.exists(pdf_path):
            os.remove(pdf_path)


class TestLeftThumbModelIntegrity(unittest.TestCase):
    """Verify finger_used is metadata only and cannot alter predictions."""

    def test_no_forced_prediction_by_finger_used(self):
        """predict() must NOT accept finger_used (prevents modification of pipeline)."""
        from src.predictor import BloodGroupPredictor
        import inspect
        sig = inspect.signature(BloodGroupPredictor.predict)
        self.assertNotIn("finger_used", list(sig.parameters.keys()),
            msg="predict() must NOT accept finger_used")

    def test_predict_consensus_no_finger_used_param(self):
        """predict_consensus() must NOT accept finger_used."""
        from src.predictor import BloodGroupPredictor
        import inspect
        sig = inspect.signature(BloodGroupPredictor.predict_consensus)
        self.assertNotIn("finger_used", list(sig.parameters.keys()),
            msg="predict_consensus() must NOT accept finger_used")

    def test_finger_used_column_is_text_metadata(self):
        """finger_used DB column is TEXT (metadata), not a numeric prediction driver."""
        db = _temp_db()
        try:
            init_db(db)
            conn = sqlite3.connect(db)
            col_info = {
                row[1]: row[2]
                for row in conn.execute("PRAGMA table_info(predictions)").fetchall()
            }
            conn.close()
            self.assertIn("finger_used", col_info)
            self.assertEqual(col_info["finger_used"], "TEXT")
        finally:
            if os.path.exists(db):
                os.remove(db)

    def test_model_probabilities_sum_to_one(self):
        """Probability dicts sum to 1.0 regardless of finger metadata."""
        total = sum(_sample_probs().values())
        self.assertAlmostEqual(total, 1.0, places=5)


if __name__ == "__main__":
    unittest.main()
import os
import unittest
from src.mfs100.scanner import MFS100Scanner

class TestMFS100Scanner(unittest.TestCase):
    def setUp(self):
        self.scanner = MFS100Scanner(mock=True)

    def test_connect_and_info(self):
        connected = self.scanner.connect()
        self.assertTrue(connected)
        self.assertTrue(self.scanner.is_connected())

        info = self.scanner.get_device_info()
        self.assertEqual(info["model"], "MFS100")
        self.assertTrue(info["mock_mode"])
        self.assertTrue(info["is_connected"])

    def test_mock_capture(self):
        self.scanner.connect()
        # Test random capture
        img_path, img_bytes = self.scanner.capture()
        self.assertTrue(os.path.exists(img_path))
        self.assertGreater(len(img_bytes), 1000)

        # Test specific class sample capture
        img_path_b, img_bytes_b = self.scanner.capture(sample_class="B+")
        self.assertTrue(os.path.exists(img_path_b))
        self.assertGreater(len(img_bytes_b), 1000)

    def test_disconnect(self):
        self.scanner.disconnect()
        self.assertFalse(self.scanner.is_connected())

if __name__ == "__main__":
    unittest.main()
"""
tests/test_mfs100_bridge.py
Unit and endpoint tests for the MFS100 32-bit HTTP Bridge.
"""

import os
import io
import json
import base64
import unittest
from unittest.mock import MagicMock, patch
from PIL import Image

class TestMFS100BridgeEndpoints(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # We can test the Flask app in bridge.py directly
        import src.mfs100_bridge.bridge as bridge_mod
        cls.bridge_mod = bridge_mod
        cls.app = bridge_mod.app.test_client()

    def test_status_endpoint(self):
        """Tests GET /status returns expected keys and structure."""
        resp = self.app.get("/status")
        self.assertIn(resp.status_code, (200, 500))
        data = json.loads(resp.data)
        self.assertIn("running", data)
        self.assertTrue(data["running"])
        self.assertIn("version", data)
        self.assertIn("python_arch", data)

    def test_connect_endpoint_mocked(self):
        """Tests POST /connect endpoint with mocked SDK instance."""
        mock_mfs = MagicMock()
        mock_mfs.Init.return_value = 0
        mock_dev = MagicMock()
        mock_dev.SerialNo = "TEST12345"
        mock_dev.Make = "MANTRA"
        mock_dev.Model = "MFS100"
        mock_dev.Width = 316
        mock_dev.Height = 354
        mock_mfs.GetDeviceInfo.return_value = mock_dev

        with patch.object(self.bridge_mod, "mfs_instance", mock_mfs), \
             patch.object(self.bridge_mod, "sdk_loaded", True):
            resp = self.app.post("/connect")
            self.assertEqual(resp.status_code, 200)
            data = json.loads(resp.data)
            self.assertTrue(data["success"])
            self.assertEqual(data["device"]["serial"], "TEST12345")

    def test_connect_failure(self):
        """Tests POST /connect when Init fails."""
        mock_mfs = MagicMock()
        mock_mfs.Init.return_value = -1307 # Device not connected
        mock_mfs.GetErrorMsg.return_value = "Device not connected"

        with patch.object(self.bridge_mod, "mfs_instance", mock_mfs), \
             patch.object(self.bridge_mod, "sdk_loaded", True):
            resp = self.app.post("/connect")
            self.assertEqual(resp.status_code, 400)
            data = json.loads(resp.data)
            self.assertFalse(data["success"])
            self.assertEqual(data["error_code"], -1307)

    def test_capture_endpoint_mocked(self):
        """Tests POST /capture successfully encodes and returns image data."""
        # Create a tiny 10x10 BMP image
        img = Image.new("L", (316, 354), color=128)
        buf = io.BytesIO()
        img.save(buf, format="BMP")
        bmp_bytes = buf.getvalue()

        mock_mfs = MagicMock()
        mock_mfs.Init.return_value = 0
        mock_fd = MagicMock()
        mock_fd.Quality = 75
        mock_fd.Nfiq = 1
        mock_fd.FingerImage = MagicMock()

        # Mock AutoCapture to return (0, mock_fd)
        mock_mfs.AutoCapture.return_value = (0, mock_fd)
        mock_mfs.BitmapToBytes.return_value = bmp_bytes

        with patch.object(self.bridge_mod, "mfs_instance", mock_mfs), \
             patch.object(self.bridge_mod, "FingerDataClass", MagicMock(return_value=mock_fd)), \
             patch.object(self.bridge_mod, "sdk_loaded", True), \
             patch.object(self.bridge_mod, "is_device_initialized", True):
            resp = self.app.post("/capture", json={"timeout_ms": 2000, "quality": 60})
            self.assertEqual(resp.status_code, 200)
            data = json.loads(resp.data)
            self.assertTrue(data["success"])
            self.assertEqual(data["quality"], 75)
            self.assertEqual(data["nfiq"], 1)
            self.assertIn("image_b64", data)

            decoded = base64.b64decode(data["image_b64"])
            self.assertTrue(decoded.startswith(b"BM"))

    def test_disconnect_endpoint(self):
        """Tests POST /disconnect."""
        mock_mfs = MagicMock()
        with patch.object(self.bridge_mod, "mfs_instance", mock_mfs), \
             patch.object(self.bridge_mod, "sdk_loaded", True):
            resp = self.app.post("/disconnect")
            self.assertEqual(resp.status_code, 200)
            data = json.loads(resp.data)
            self.assertTrue(data["success"])

if __name__ == "__main__":
    unittest.main()
import os
import sys
import json
import hashlib
import numpy as np
import pytest
from PIL import Image

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Day 1 Model Hash
EXPECTED_DAY1_MODEL_HASH = "7b5ff5d94d4ce3de7d432fcfb3e0ad71b508d69f7e993ca93075bba67ea12de9"

# Locked 8-class production files established in repository suite
EXPECTED_PROTECTED_HASHES = {
    "models/resnet50_improved_blood_group.keras": "a377510597cc216e95f3f4aad7f59c61e2d29ad4723363ffdda767dbc927a1f2",
    "models/vgg16_blood_group.keras": "7f46e1c52000773e98656c87278107c10350095384df1c3bdf12319d6632cc6c",
    "models/efficientnetb0_blood_group.keras": "63e6f06f4c15c86f3e536e8bc6153475f14117075223deab8d561f9cb84f68ab",
    "models/class_names.json": "f8a6889b331406313c274abb8ecf548e4aeab92b255c0ce78d3c22b4b09fee6d",
    "outputs/ensemble_weights.json": "12f23f6ce7562c4852a6e9f96560d58fda4636bc8f40d02149398db46743d604",
    "src/config.py": "e0616ca178744f8d20e7cae6a6cb1177f46e2f373a2e044ba56c74ac930d817f",
    "src/preprocessing.py": "569cdec24d516c8b8b66856623566287fb9c6b3f1deb35a345d6bc8d851146f7",
    "src/predictor.py": "ceb4c34ed082a8182ef32ee39f38660943320a16cc4aa9d30acf2a9cce0d4e5e"
}

EXPECTED_CLASS_MAPPING = {
    "A+": 0,
    "AB+": 1,
    "B+": 2,
    "O+": 3
}

def compute_sha256(filepath):
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def test_raw_mfs100_handling():
    """Test 1: Raw MFS100 316x354 image handling and resizing to 224x224x3."""
    from src.preprocessing import composite_alpha_on_white, resize_to_target
    img = Image.new("L", (316, 354), color=255)
    img_rgb = composite_alpha_on_white(img)
    resized = resize_to_target(img_rgb, (224, 224))
    arr = np.array(resized, dtype=np.float32)
    assert arr.shape == (224, 224, 3)
    assert arr.min() >= 0.0 and arr.max() <= 255.0

def test_crop_coordinates_inside_boundaries():
    """Test 2: Crop coordinates stay inside [0, 316] and [0, 354] boundaries."""
    from src.preprocessing import crop_mfs100_foreground
    arr = np.ones((354, 316), dtype=np.uint8) * 255
    arr[100:250, 80:220] = 50
    patch_img = Image.fromarray(arr)
    cropped_img, metadata = crop_mfs100_foreground(patch_img)
    x1, y1, x2, y2 = metadata["bbox"]
    assert 0 <= x1 < x2 <= 316
    assert 0 <= y1 < y2 <= 354

def test_crop_dimensions_gte_80():
    """Test 3: Crop dimensions >= 80x80."""
    from src.preprocessing import crop_mfs100_foreground
    arr = np.ones((354, 316), dtype=np.uint8) * 255
    arr[100:250, 80:220] = 50
    patch_img = Image.fromarray(arr)
    cropped_img, metadata = crop_mfs100_foreground(patch_img)
    x1, y1, x2, y2 = metadata["bbox"]
    width = x2 - x1
    height = y2 - y1
    assert width >= 80
    assert height >= 80

def test_crop_output_224x224x3():
    """Test 4: Cropped image after Lanczos resize is 224x224x3."""
    from src.preprocessing import crop_mfs100_foreground, composite_alpha_on_white, resize_to_target
    arr = np.ones((354, 316), dtype=np.uint8) * 255
    arr[100:250, 80:220] = 50
    patch_img = Image.fromarray(arr)
    cropped_img, metadata = crop_mfs100_foreground(patch_img)
    comp = composite_alpha_on_white(cropped_img)
    resized = resize_to_target(comp, (224, 224))
    res_arr = np.array(resized, dtype=np.float32)
    assert res_arr.shape == (224, 224, 3)

def test_day1_model_output_dimension():
    """Test 5: Day 1 model output dimension is exactly 4."""
    import tensorflow as tf
    model_path = os.path.join(PROJECT_ROOT, "models", "abo_positive_4class", "best_model.keras")
    assert os.path.exists(model_path)
    model = tf.keras.models.load_model(model_path, compile=False)
    assert model.output_shape[-1] == 4

def test_softmax_probabilities_sum():
    """Test 6: Softmax probabilities sum to 1 ± 1e-4."""
    import tensorflow as tf
    model_path = os.path.join(PROJECT_ROOT, "models", "abo_positive_4class", "best_model.keras")
    model = tf.keras.models.load_model(model_path, compile=False)
    dummy_input = np.random.uniform(0, 255, (2, 224, 224, 3)).astype(np.float32)
    preds = model.predict(dummy_input, verbose=0)
    for p in preds:
        assert np.isclose(np.sum(p), 1.0, atol=1e-4)

def test_exact_class_mapping():
    """Test 7: Exact class mapping matches Day 1 specification."""
    mapping_path = os.path.join(PROJECT_ROOT, "models", "abo_positive_4class", "class_mapping.json")
    assert os.path.exists(mapping_path)
    with open(mapping_path, "r") as f:
        mapping = json.load(f)
    assert mapping["class_to_id"] == EXPECTED_CLASS_MAPPING

def test_no_mfs100_in_training():
    """Test 8: No MFS100 image was used in training/validation splits."""
    for split in ["train", "val", "test"]:
        csv_path = os.path.join(PROJECT_ROOT, "outputs", "abo_positive_4class", f"data_manifest_{split}.csv")
        if os.path.exists(csv_path):
            with open(csv_path, "r") as f:
                content = f.read()
            assert "data/captured" not in content
            assert "MFS100" not in content
            assert "BMP" not in content

def test_day1_model_sha256_unchanged():
    """Test 9: Day 1 model SHA-256 hash is unchanged."""
    model_path = os.path.join(PROJECT_ROOT, "models", "abo_positive_4class", "best_model.keras")
    assert os.path.exists(model_path)
    actual_hash = compute_sha256(model_path)
    assert actual_hash == EXPECTED_DAY1_MODEL_HASH, f"Day 1 model hash changed! {actual_hash} vs {EXPECTED_DAY1_MODEL_HASH}"

def test_protected_files_sha256_unchanged():
    """Test 10: All protected 8-class production files are unchanged."""
    for rel_path, expected_hash in EXPECTED_PROTECTED_HASHES.items():
        filepath = os.path.join(PROJECT_ROOT, rel_path)
        assert os.path.exists(filepath), f"Protected file missing: {filepath}"
        actual_hash = compute_sha256(filepath)
        assert actual_hash == expected_hash, f"Protected file {filepath} altered! {actual_hash} vs {expected_hash}"
"""
tests/test_mfs100_integration.py
End-to-end integration tests for MFS100 fingerprint capture pipeline.
Verifies:
- Scanner status & mode toggle endpoints
- Mock capture -> Preprocessing -> Model Prediction -> DB Logging -> PDF Report
- Simulated hardware capture -> Preprocessing -> Prediction -> DB Logging -> PDF Report
"""

import os
import io
import json
import base64
import unittest
from unittest.mock import patch, MagicMock
from PIL import Image

from app import app
from src.database import get_prediction_by_id

class TestMFS100EndToEndIntegration(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_scanner_status_endpoint(self):
        """Tests /api/scanner/status returns correct schema."""
        resp = self.client.get("/api/scanner/status")
        self.assertEqual(resp.status_code, 200)
        data = resp.json
        self.assertIn("mock_mode", data)
        self.assertIn("is_connected", data)
        self.assertIn("bridge_health", data)
        self.assertIn("device", data)

    def test_scanner_mode_toggle(self):
        """Tests /api/scanner/mode toggles between mock and hardware modes."""
        # Force mock = True
        resp = self.client.post("/api/scanner/mode", json={"mock": True})
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(resp.json["mock_mode"])

        # Force mock = False
        resp2 = self.client.post("/api/scanner/mode", json={"mock": False})
        self.assertEqual(resp2.status_code, 200)
        self.assertFalse(resp2.json["mock_mode"])

        # Reset back to mock = True for safe default
        self.client.post("/api/scanner/mode", json={"mock": True})

    def test_capture_mock_pipeline(self):
        """Tests full biometric inference pipeline using mock capture."""
        # Ensure in mock mode
        self.client.post("/api/scanner/mode", json={"mock": True})

        resp = self.client.post("/api/capture", json={"sample_class": "B+"})
        self.assertEqual(resp.status_code, 200)
        data = resp.json

        self.assertTrue(data["success"])
        self.assertIn("blood_group", data)
        self.assertIn("confidence", data)
        self.assertIn("prediction_id", data)
        self.assertIn("probabilities", data)
        self.assertEqual(len(data["probabilities"]), 8)

        pred_id = data["prediction_id"]
        db_rec = get_prediction_by_id(pred_id)
        self.assertIsNotNone(db_rec)
        self.assertEqual(db_rec["predicted_group"], data["blood_group"])

    @patch("requests.post")
    def test_capture_hardware_pipeline_simulated(self, mock_post):
        """Tests full biometric inference pipeline with simulated hardware capture."""
        # Set hardware mode
        self.client.post("/api/scanner/mode", json={"mock": False})

        # Generate a synthetic 316x354 BMP fingerprint frame
        img = Image.new("L", (316, 354), color=210)
        buf = io.BytesIO()
        img.save(buf, format="BMP")
        bmp_bytes = buf.getvalue()
        b64_str = base64.b64encode(bmp_bytes).decode("utf-8")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.headers = {"content-type": "application/json"}
        mock_resp.json.return_value = {
            "success": True,
            "image_b64": b64_str,
            "quality": 85,
            "nfiq": 1
        }
        mock_post.return_value = mock_resp

        # Trigger capture
        resp = self.client.post("/api/capture")
        self.assertEqual(resp.status_code, 200)
        data = resp.json

        self.assertTrue(data["success"])
        self.assertIn("blood_group", data)
        self.assertIn("confidence", data)
        self.assertEqual(data["scanner_mode"], "hardware")

        pred_id = data["prediction_id"]
        db_rec = get_prediction_by_id(pred_id)
        self.assertIsNotNone(db_rec)
        self.assertEqual(db_rec["input_type"], "MFS100")

        # Cleanup: switch back to mock
        self.client.post("/api/scanner/mode", json={"mock": True})

if __name__ == "__main__":
    unittest.main()
"""
tests/test_mfs100_scanner.py
Unit tests for the refactored MFS100Scanner adapter.
Verifies both mock mode and bridge HTTP mode.
"""

import os
import io
import base64
import unittest
from unittest.mock import patch, MagicMock
from PIL import Image

from src.mfs100.scanner import MFS100Scanner

class TestMFS100Scanner(unittest.TestCase):
    def setUp(self):
        # Default scanner in mock mode
        self.scanner = MFS100Scanner(mock=True)

    def test_mock_connect_and_disconnect(self):
        """Tests standard mock connection lifecycle."""
        self.assertTrue(self.scanner.connect())
        self.assertTrue(self.scanner.is_connected())

        info = self.scanner.get_device_info()
        self.assertEqual(info["model"], "MFS100")
        self.assertTrue(info["mock_mode"])
        self.assertTrue(info["is_connected"])

        self.assertTrue(self.scanner.disconnect())
        self.assertFalse(self.scanner.is_connected())

    def test_mock_capture(self):
        """Tests capture in mock mode."""
        self.scanner.connect()
        img_path, img_bytes = self.scanner.capture()
        self.assertTrue(os.path.exists(img_path))
        self.assertGreater(len(img_bytes), 1000)
        self.assertTrue(img_bytes.startswith(b"BM"))

        # Capture specific sample
        img_path_a, img_bytes_a = self.scanner.capture(sample_class="A+")
        self.assertTrue(os.path.exists(img_path_a))
        self.assertGreater(len(img_bytes_a), 1000)

    @patch("requests.post")
    def test_hardware_mode_connect_success(self, mock_post):
        """Tests hardware mode connection when bridge responds successfully."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.headers = {"content-type": "application/json"}
        mock_resp.json.return_value = {
            "success": True,
            "device": {
                "serial": "11215389",
                "model": "MFS100",
                "make": "MANTRA",
                "width": 316,
                "height": 354
            }
        }
        mock_post.return_value = mock_resp

        hw_scanner = MFS100Scanner(mock=False, bridge_url="http://127.0.0.1:5100")
        connected = hw_scanner.connect()
        self.assertTrue(connected)
        self.assertTrue(hw_scanner.is_connected())
        self.assertFalse(hw_scanner.mock)

        info = hw_scanner.get_device_info()
        self.assertEqual(info["serial"], "11215389")
        self.assertEqual(info["status"], "CONNECTED (PHYSICAL)")

    @patch("requests.post")
    def test_hardware_mode_capture(self, mock_post):
        """Tests hardware mode capture and BMP validation."""
        # Create a valid BMP
        img = Image.new("L", (316, 354), color=200)
        buf = io.BytesIO()
        img.save(buf, format="BMP")
        valid_bmp = buf.getvalue()
        b64_str = base64.b64encode(valid_bmp).decode("utf-8")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.headers = {"content-type": "application/json"}
        mock_resp.json.return_value = {
            "success": True,
            "image_b64": b64_str,
            "quality": 82,
            "nfiq": 1
        }
        mock_post.return_value = mock_resp

        hw_scanner = MFS100Scanner(mock=False, bridge_url="http://127.0.0.1:5100")
        hw_scanner._connected = True

        out_path, img_bytes = hw_scanner.capture()
        self.assertTrue(os.path.exists(out_path))
        self.assertEqual(img_bytes, valid_bmp)
        self.assertTrue(img_bytes.startswith(b"BM"))

    @patch("requests.get")
    def test_bridge_healthcheck(self, mock_get):
        """Tests bridge health check probe."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"running": True, "python_arch": "32bit"}
        mock_get.return_value = mock_resp

        hw_scanner = MFS100Scanner(mock=False, bridge_url="http://127.0.0.1:5100")
        health = hw_scanner.check_bridge_health()
        self.assertTrue(health["reachable"])
        self.assertEqual(health["data"]["python_arch"], "32bit")

if __name__ == "__main__":
    unittest.main()
import os
import unittest
import numpy as np
from src.config import SAMPLE_IMAGE_DIR, CLASS_NAMES
from src.predictor import BloodGroupPredictor

class TestBloodGroupPredictor(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.predictor = BloodGroupPredictor()

    def test_predictor_ready(self):
        self.assertTrue(self.predictor.is_model_ready())
        self.assertEqual(len(self.predictor.class_names), 8)

    def test_prediction_output_structure(self):
        sample_path = os.path.join(SAMPLE_IMAGE_DIR, "O+.bmp")
        if os.path.exists(sample_path):
            res = self.predictor.predict(sample_path)
            
            self.assertIn("blood_group", res)
            self.assertIn(res["blood_group"], CLASS_NAMES)
            self.assertIn("confidence", res)
            self.assertIsInstance(res["confidence"], float)
            self.assertGreaterEqual(res["confidence"], 0.0)
            self.assertLessEqual(res["confidence"], 1.0)
            self.assertIn("status", res)
            self.assertIn(res["status"], ["NORMAL", "LOW_CONFIDENCE"])
            self.assertIn("probabilities", res)
            self.assertEqual(len(res["probabilities"]), 8)

            # Probabilities should sum closely to 1.0
            prob_sum = sum(res["probabilities"].values())
            self.assertAlmostEqual(prob_sum, 1.0, places=2)

    def test_threshold_flag(self):
        sample_path = os.path.join(SAMPLE_IMAGE_DIR, "A-.bmp")
        if os.path.exists(sample_path):
            res = self.predictor.predict(sample_path)
            if res["confidence"] < self.predictor.ADVISORY_CONFIRMATION_THRESHOLD:
                self.assertEqual(res["status"], "LOW_CONFIDENCE")
                self.assertTrue(res["is_low_confidence"])
            else:
                self.assertEqual(res["status"], "NORMAL")
                self.assertFalse(res["is_low_confidence"])

    def test_predict_consensus(self):
        sample_path = os.path.join(SAMPLE_IMAGE_DIR, "A+.bmp")
        if os.path.exists(sample_path):
            # Pass 3 identical images to simulate 3 impressions of the same finger
            res = self.predictor.predict_consensus([sample_path, sample_path, sample_path])
            self.assertIn("blood_group", res)
            self.assertIn(res["blood_group"], CLASS_NAMES)
            self.assertIn("consensus_metadata", res)
            cm = res["consensus_metadata"]
            self.assertEqual(cm["num_scans"], 3)
            self.assertEqual(cm["agreement_pct"], 100)
            self.assertEqual(len(cm["individual_scans"]), 3)
            self.assertIn("abo_analysis", res)

    def test_abo_rh_decomposition(self):
        # Test synthetic probability distribution
        mock_probs = {
            "A+": 0.10, "A-": 0.05,
            "B+": 0.05, "B-": 0.02,
            "AB+": 0.02, "AB-": 0.01,
            "O+": 0.65, "O-": 0.10
        }
        res = self.predictor._decompose_blood_group(mock_probs, "O+", 0.65)
        self.assertEqual(res["abo_group"], "O")
        self.assertAlmostEqual(res["abo_confidence"], 0.75, places=2)
        self.assertEqual(res["rh_factor"], "+")
        self.assertAlmostEqual(res["rh_margin"], 0.55, places=2)
        # Margin is 0.55 and confidence is 0.65 and rh is +, so not uncertain
        self.assertFalse(res["rh_uncertainty"])
        self.assertIsNone(res["rh_warning"])

    def test_rh_uncertainty_trigger_on_negative_or_narrow_margin(self):
        # Test case: narrow margin between AB+ and AB-
        mock_probs = {
            "A+": 0.01, "A-": 0.01,
            "B+": 0.02, "B-": 0.01,
            "AB+": 0.46, "AB-": 0.44,
            "O+": 0.03, "O-": 0.02
        }
        res = self.predictor._decompose_blood_group(mock_probs, "AB+", 0.46)
        self.assertEqual(res["abo_group"], "AB")
        self.assertTrue(res["rh_uncertainty"])
        self.assertIsNotNone(res["rh_warning"])
        self.assertIn("Standard serological laboratory blood typing is required", res["rh_warning"])

        # Test case: predicted Rh- triggers advisory rule
        mock_probs_neg = {
            "A+": 0.05, "A-": 0.01,
            "B+": 0.02, "B-": 0.01,
            "AB+": 0.01, "AB-": 0.01,
            "O+": 0.10, "O-": 0.80
        }
        res_neg = self.predictor._decompose_blood_group(mock_probs_neg, "O-", 0.80)
        self.assertEqual(res_neg["abo_group"], "O")
        self.assertEqual(res_neg["rh_factor"], "-")
        self.assertTrue(res_neg["rh_uncertainty"])
        self.assertIn("predicted Rh-negative", res_neg["rh_warning"])

if __name__ == "__main__":
    unittest.main()


import os
import io
import unittest
import numpy as np
from PIL import Image
import tensorflow as tf

from src.preprocessing import (
    load_image_to_pil,
    composite_alpha_on_white,
    resize_to_target,
    preprocess_fingerprint,
    load_and_preprocess_for_training
)
from src.config import IMAGE_SIZE

class TestPreprocessingPipeline(unittest.TestCase):
    def setUp(self):
        self.project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        self.sample_dir = os.path.join(self.project_root, "data", "sample")

    def test_composite_alpha_on_white(self):
        # Create a test RGBA image with 1 transparent pixel and 1 black pixel
        rgba = np.zeros((10, 10, 4), dtype=np.uint8)
        # Pixel (0, 0) is fully transparent
        rgba[0, 0] = [0, 0, 0, 0]
        # Pixel (5, 5) is opaque black
        rgba[5, 5] = [0, 0, 0, 255]
        # Pixel (9, 9) is opaque white
        rgba[9, 9] = [255, 255, 255, 255]

        pil_rgba = Image.fromarray(rgba, mode="RGBA")
        rgb_result = composite_alpha_on_white(pil_rgba)

        self.assertEqual(rgb_result.mode, "RGB")
        res_arr = np.array(rgb_result)

        # Transparent pixel should become (255, 255, 255)
        np.testing.assert_array_equal(res_arr[0, 0], [255, 255, 255])
        # Opaque black should remain (0, 0, 0)
        np.testing.assert_array_equal(res_arr[5, 5], [0, 0, 0])
        # Opaque white should remain (255, 255, 255)
        np.testing.assert_array_equal(res_arr[9, 9], [255, 255, 255])

    def test_resize_to_target(self):
        img = Image.new("RGB", (96, 103), color=(128, 128, 128))
        resized = resize_to_target(img, target_size=(224, 224))
        self.assertEqual(resized.size, (224, 224))

    def test_preprocess_fingerprint_from_filepath(self):
        sample_path = os.path.join(self.sample_dir, "A+.bmp")
        if os.path.exists(sample_path):
            batch_tensor, display_pil = preprocess_fingerprint(sample_path)
            self.assertEqual(batch_tensor.shape, (1, 224, 224, 3))
            self.assertEqual(batch_tensor.dtype, np.float32)
            self.assertEqual(display_pil.size, (224, 224))
            self.assertEqual(display_pil.mode, "RGB")

    def test_preprocess_fingerprint_from_bytes(self):
        img = Image.new("RGB", (150, 150), color=(200, 200, 200))
        buf = io.BytesIO()
        img.save(buf, format="BMP")
        img_bytes = buf.getvalue()

        batch_tensor, display_pil = preprocess_fingerprint(img_bytes)
        self.assertEqual(batch_tensor.shape, (1, 224, 224, 3))
        self.assertEqual(display_pil.size, (224, 224))

    def test_load_and_preprocess_for_training(self):
        sample_path = os.path.join(self.sample_dir, "O+.bmp")
        if os.path.exists(sample_path):
            tensor = load_and_preprocess_for_training(sample_path)
            self.assertEqual(tensor.shape, (224, 224, 3))
            self.assertEqual(tensor.dtype, np.float32)

    def test_enhance_mfs100_ridge_contrast(self):
        from src.preprocessing import enhance_mfs100_ridge_contrast, preprocess_for_ensemble
        # Create low-contrast synthetic image simulating MFS100 gray ridges
        arr = np.full((354, 316), 200, dtype=np.uint8)
        arr[50:300:10, 50:250] = 120  # simulated gray ridges
        img = Image.fromarray(arr, mode="L")

        enhanced = enhance_mfs100_ridge_contrast(img)
        self.assertEqual(enhanced.size, (316, 354))
        self.assertEqual(enhanced.mode, "RGB")
        enh_arr = np.array(enhanced)
        # Contrast standard deviation should increase
        self.assertGreater(float(np.std(enh_arr)), float(np.std(arr)))

    def test_preprocess_for_ensemble_source_aware(self):
        from src.preprocessing import preprocess_for_ensemble
        sample_path = os.path.join(self.sample_dir, "A+.bmp")
        if os.path.exists(sample_path):
            # Upload source must NOT apply MFS100 enhancement or cropping
            up_res = preprocess_for_ensemble(sample_path, source="upload")
            self.assertFalse(up_res["crop_metadata"]["crop_applied"])
            self.assertFalse(up_res["crop_metadata"]["enhancement_applied"])

            # MFS100 source MUST set enhancement_applied=True
            mfs_res = preprocess_for_ensemble(sample_path, source="mfs100")
            self.assertTrue(mfs_res["crop_metadata"]["enhancement_applied"])

if __name__ == "__main__":
    unittest.main()

import os
import unittest
import PyPDF2, io

from src.report_generator import generate_pdf_report
from src.config import SAMPLE_IMAGE_DIR

class TestReportGenerator(unittest.TestCase):
    def test_generate_pdf_report_with_model_name(self):
        """Verify that the generated PDF includes the provided model name."""
        sample_img = os.path.join(SAMPLE_IMAGE_DIR, "A+.bmp")
        model_name = "Champion Ensemble V2 (ResNet50 58% + VGG16 38% + EffNet 4%)"
        pdf_path = generate_pdf_report(
            prediction_id=7777,
            timestamp="2026-09-04 10:00:00",
            input_type="MFS100 (Mock)",
            image_path=sample_img if os.path.exists(sample_img) else None,
            predicted_group="A+",
            confidence=0.90,
            probabilities={"A+": 0.9, "O+": 0.1},
            status="NORMAL",
            model_name=model_name,
        )
        self.assertTrue(os.path.exists(pdf_path))
        with open(pdf_path, "rb") as f:
            pdf_bytes = f.read()
        # Parse PDF from in-memory bytes
        reader = PyPDF2.PdfReader(io.BytesIO(pdf_bytes))
        text = ""
        for page in reader.pages:
            extracted = page.extract_text()
            if extracted:
                text += extracted
        # Check that the base model name (before parentheses) appears
        base_name = model_name.split('(')[0].strip()
        self.assertIn(base_name, text)
        os.remove(pdf_path)

    def test_generate_pdf_report(self):
        """Basic PDF generation without optional fields."""
        sample_img = os.path.join(SAMPLE_IMAGE_DIR, "A+.bmp")
        probs = {
            "A+": 0.85,
            "A-": 0.03,
            "AB+": 0.04,
            "AB-": 0.01,
            "B+": 0.02,
            "B-": 0.01,
            "O+": 0.03,
            "O-": 0.01,
        }
        pdf_path = generate_pdf_report(
            prediction_id=9999,
            timestamp="2026-09-03 23:45:00",
            input_type="MFS100 (Mock)",
            image_path=sample_img if os.path.exists(sample_img) else None,
            predicted_group="A+",
            confidence=0.85,
            probabilities=probs,
            status="NORMAL",
        )
        self.assertTrue(os.path.exists(pdf_path))
        self.assertGreater(os.path.getsize(pdf_path), 5000)
        os.remove(pdf_path)

    def test_generate_pdf_report_with_rh_uncertainty(self):
        """PDF generation with Rh factor uncertainty advisory banner."""
        sample_img = os.path.join(SAMPLE_IMAGE_DIR, "AB+.bmp")
        probs = {
            "A+": 0.01,
            "A-": 0.01,
            "AB+": 0.48,
            "AB-": 0.46,
            "B+": 0.01,
            "B-": 0.01,
            "O+": 0.01,
            "O-": 0.01,
        }
        abo_analysis = {
            "abo_group": "AB",
            "abo_confidence": 0.94,
            "rh_factor": "+",
            "rh_uncertainty": True,
            "rh_warning": "Rh factor (±) determination is uncertain (narrow Rh margin). Laboratory serology required.",
        }
        pdf_path = generate_pdf_report(
            prediction_id=8888,
            timestamp="2026-09-05 12:00:00",
            input_type="MFS100 Hardware",
            image_path=sample_img if os.path.exists(sample_img) else None,
            predicted_group="AB+",
            confidence=0.48,
            probabilities=probs,
            status="LOW_CONFIDENCE",
            abo_analysis=abo_analysis,
        )
        self.assertTrue(os.path.exists(pdf_path))
        self.assertGreater(os.path.getsize(pdf_path), 5000)
        os.remove(pdf_path)

if __name__ == "__main__":
    unittest.main()
